package com.example.userregistrationjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserregistrationjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserregistrationjwtApplication.class, args);
	}

}
