package com.example.userregistrationjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserregistrationjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
